package proyectocs;

import controller.LoginController;
import model.Persistence;
import model.UserModel;
import model.LoginQueries;
import view.LoginView;

public class ProyectoCs {
    public static void main(String[] args){
        new LoginController();
    }
}
