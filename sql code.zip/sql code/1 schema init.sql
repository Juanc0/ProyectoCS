DROP SCHEMA IF EXISTS proyectocs;
CREATE SCHEMA proyectocs;
USE proyectocs;